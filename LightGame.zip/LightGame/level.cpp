#include "level.h"
#include "action.h"

bool mousedown = false;

Level::Level(sf::RenderWindow &window)
    : Application(window)
{
    _window.setTitle("Lightbot: Learn to code!");
    _grid = new Grid();

    _secProg = new ExecSecProg(1200,0,Type_Action::sec_prog);
    _changeAltitude = new Action(1200,80,Type_Action::change_Altitude);
    _forward = new Action(1200,160,Type_Action::forward);
    _rotation_Left = new Action(1200,240,Type_Action::rotate_Left);
    _rotation_Right = new Action(1200,320,Type_Action::rotate_Right);
    _light = new Action(1200,600,Type_Action::light_Hex);
    _primaryProg = new PrimaryProg();


    _quit.setFillColor(sf::Color::Red);
    _quit.setPosition(1200,700);
    _quit.setSize({40,40});

    _actionPannel.push_back(_secProg);
    _actionPannel.push_back(_changeAltitude);
    _actionPannel.push_back(_forward);
    _actionPannel.push_back(_rotation_Right);
    _actionPannel.push_back(_rotation_Left);
    _actionPannel.push_back(_light);


    _robot = new Robot();
    _robot->setPosition( *_grid->getGrid().at(0));
    //  std::cout<< _grid->getGrid().at(2)->getPosition().x <<std::endl;
}

void Level::launch_exec()
{
    for(Action *a : _primaryProg->getPrimProg())
    {
        a->displayAction(_window);
    }

}

void Level::loop()
{
    _window.clear(sf::Color::White);
    _forward->displayAction(_window);
    _rotation_Left->displayAction(_window);
    _rotation_Right->displayAction(_window);
    _changeAltitude->displayAction(_window);
    _light->displayAction(_window);
    _secProg->displayAction(_window);
    _grid->display(_window);
    _robot->draw_bot(_window);
    _primaryProg->drawPrimProg(_window);
    displayLevelButtons();



    mouse_button_pressed();
    launch_exec();
    //  std::cout<< "POSITIONNN : " << _grid->getGrid().at(2)->getPosition().x <<std::endl;
    // std::cout<< "ORIGINE " << _grid->getGrid().at(2)->getPosition().x <<std::endl;


    // std::cout << "X ROBOT " <<_robot->getPosition().x << std::endl;
    //  launch_exec();
    _window.display();





}

void Level::mouse_button_pressed()
{
    if(_changeAltitude->getDimension().getGlobalBounds().contains(_mouse))
    {
        Action  *_ACA = new Action(_primaryProg->getShift_X(),_primaryProg->getShift_Y(),Type_Action::forward);
        _primaryProg->addAction(*_ACA);
       // _primaryProg->setShift(70);



        std::cout<<"CHANGE ALTITUDE" << std::endl;

    }
    if(_forward->getDimension().getGlobalBounds().contains(_mouse))
    {
        Action  *_AF = new Action(30,45,Type_Action::forward);
        _primaryProg->addAction(*_AF);


        std::cout<<"FORWARD" << std::endl;

    }

    if(_rotation_Left->getDimension().getGlobalBounds().contains(_mouse) )
    {
        Action  *_ARL= new Action(45,45,Type_Action::rotate_Left);
        _primaryProg->addAction(*_ARL);


        std::cout<<"ROTATE LEFT " << std::endl;

    }

    if(_rotation_Right->getDimension().getGlobalBounds().contains(_mouse) )
    {
        Action  *_ARR= new Action(45,45,Type_Action::rotate_Right);
        _primaryProg->addAction(*_ARR);

        std::cout<<"ROTATE RIGHT" << std::endl;

    }


    if(_light->getDimension().getGlobalBounds().contains(_mouse) )
    {
        Action  *_AL= new Action(45,45,Type_Action::light_Hex);
        _primaryProg->addAction(*_AL);

        std::cout<<"LIGHT_HEX" << std::endl;

    }

    if(_secProg->getDimension().getGlobalBounds().contains(_mouse))
    {
        ExecSecProg *_SP = new ExecSecProg(45,45,Type_Action::light_Hex);
        _primaryProg->addAction(*_SP);
        std::cout<<"SEC PROOOG" << std::endl;

    }

    if(_quit.getGlobalBounds().contains(_mouse))
    {
        exit(0);
    }

    std::cout <<" PRIMARY PROG : " << _primaryProg->getPrimProg().size() << std::endl;

}

void Level::mouse_button_released()
{

}


void Level::displayLevelButtons()
{
    _window.draw(_quit);

}



//bool Level::isMouseInEntity(const sf::Vector2i &mouse, const sf::FloatRect &entity)
//{

//    return  (mouse.y>=(entity.top) &&
//            (mouse.y <=entity.top+entity.height)&&
//            (mouse.x>=entity.left)&&
//            (mouse.x <=entity.left+entity.width));
//       std::cout << " EZZZZZZZZZZZZZZZ";

//}

//void Level::setMousePos(int x,int y)
//{
//    auto pos = _window.mapPixelToCoords( {x, y});
//    _mouse = { pos.x, pos.y };

//}
