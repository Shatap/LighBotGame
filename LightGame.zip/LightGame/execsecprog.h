#ifndef EXECSECPROG_H
#define EXECSECPROG_H
#include "action.h"

class ExecSecProg:public Action
{
public:
    ExecSecProg(int x, int y,Type_Action t);

};

#endif // EXECSECPROG_H
