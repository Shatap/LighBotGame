#include "execsecprog.h"

ExecSecProg::ExecSecProg(int x, int y, Type_Action t)
    :Action(x,y,t)
{

}
