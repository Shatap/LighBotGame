#ifndef PRIMARYPROG_H
#define PRIMARYPROG_H
#include"program.h"


class PrimaryProg: public Program
{
private:
    sf::RectangleShape _primprog;
    std::vector<Action*> _progActions;
    int _shift_X;
    int _shift_Y;
    int _x_Pos;
    int _y_Pos;
public:
    PrimaryProg();
     void addAction(Action &action) override;
     void removeAction(Action &action)override;
     void drawPrimProg(sf::RenderWindow &window);
     std::vector<Action*> getPrimProg();
     int getShift_X();
     void setShift_X(int x);
     int getShift_Y();
     void setShift_Y(int y);

};

#endif // PRIMARYPROG_H
