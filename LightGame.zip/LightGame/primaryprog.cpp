#include "primaryprog.h"

PrimaryProg::PrimaryProg()
    :Program{},_x_Pos{600},_y_Pos{400},_shift_X{600},_shift_Y{400}
{
    _primprog.setPosition({_x_Pos,_y_Pos});
    _primprog.setFillColor(sf::Color::White);
    _primprog.setSize({400,200});
    _primprog.setOutlineThickness(3);
    _primprog.setOutlineColor(sf::Color::Black);
}

void PrimaryProg::addAction(Action  &action)
{
    _progActions.push_back(&action);

}



void PrimaryProg::removeAction(Action &action)
{

}

void PrimaryProg::drawPrimProg(sf::RenderWindow & window)
{
    window.draw(_primprog);

}

std::vector<Action * > PrimaryProg::getPrimProg()
{
    return this->_progActions;
}

int PrimaryProg::getShift_X()
{
    return _shift_X;
}


void PrimaryProg::setShift_X(int x)
{
    _shift_X+=x;
}

int PrimaryProg::getShift_Y()
{
    return _shift_Y;
}

void PrimaryProg::setShift_Y(int y)
{
    _shift_Y+=y;
}

