#include "secondaryprog.h"

SecondaryProg::SecondaryProg()
{

}
