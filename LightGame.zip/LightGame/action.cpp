#include "action.h"


Action::Action(int x, int y,Type_Action t)
    :_typeAction{t}

{
    _recAction.setPosition(x,y);
    _recAction.setSize(sf::Vector2f(_ACT_WIDTH,_ACT_HEIGHT ));
    _recAction.setOutlineThickness(2);
    _recAction.setOutlineColor(sf::Color::Black);
        switch(t)
        {
        case  Type_Action::forward:
            _recAction.setFillColor(sf::Color::Cyan);
            break;
        case Type_Action::rotate_Left:
            _recAction.setFillColor(sf::Color::Blue);
            break;
        case  Type_Action::rotate_Right:
            _recAction.setFillColor(sf::Color::Yellow);
            break;
        case Type_Action::light_Hex:
            _recAction.setFillColor(sf::Color::Magenta);
            break;

        case Type_Action::sec_prog:
            _recAction.setFillColor(sf::Color::Red);
            break;

        case Type_Action::change_Altitude:
            _recAction.setFillColor(sf::Color::Green);
            break;

        }




}

void Action::setRotationLeft(Robot &r)
{
    if(this->_typeAction == Type_Action::rotate_Left)
        r.setRotationLeft();
}

void Action::setRotationRight(Robot &r)
{
    if(this->_typeAction == Type_Action::rotate_Left)
        r.setRotationRight();
}

void Action::changeAltitude(Robot  &r)
{
    if(this->_typeAction == Type_Action::change_Altitude)
    {

    }

}

void Action::moveForward(Robot  &r)
{

}

void Action::displayAction(sf::RenderWindow &window)
{
    window.draw(_recAction);

}

sf::RectangleShape  Action::getDimension() const
{
    return  _recAction;
}

