#ifndef SECONDARYPROG_H
#define SECONDARYPROG_H
#include "program.h"

class SecondaryProg:public Program
{
public:
    SecondaryProg();
};

#endif // SECONDARYPROG_H
